import json
import boto3
from botocore.exceptions import ClientError
from jose import jwt
import requests

def lambda_handler(event, context):
    # Extract username and password from the incoming event
    body = json.loads(event['body'])
    username = body['username']
    password = body['password']

    # Set your Cognito User Pool details
    user_pool_id = 'us-east-1_qhxEk5kKw'
    client_id = 'ctvqhciqbvga9gh3vjgl71fu1'

    # Initialize Cognito client
    cognito_client = boto3.client('cognito-idp')
    
    jwks_url = f'https://cognito-idp.us-east-1.amazonaws.com/{user_pool_id}/.well-known/jwks.json'
    jwks = requests.get(jwks_url).json()
    
    try:
        # Make the authentication request
        response = cognito_client.admin_initiate_auth(
            UserPoolId=user_pool_id,
            ClientId=client_id,
            AuthFlow='ADMIN_NO_SRP_AUTH',  # Use ADMIN_NO_SRP_AUTH for custom authentication flow
            AuthParameters={
                'USERNAME': username,
                'PASSWORD': password,
            }
        )
        jwt_token = response['AuthenticationResult']['AccessToken']
        
        headers = jwt.get_unverified_headers(jwt_token)
        kid = headers['kid']
        key = next((key for key in jwks['keys'] if key['kid'] == kid), None)
    
        if key:
            claims = jwt.decode(jwt_token, key, algorithms=['RS256'], audience='your_audience', issuer=f'https://cognito-idp.us-east-1.amazonaws.com/{user_pool_id}')
        
        response = {
            "userId" : claims['sub']
        }

        return {
            'statusCode': 200,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",  # Specify the allowed headers
                "Access-Control-Allow-Methods": "*",  # Specify the allowed HTTP methods
            },
            'body': json.dumps(response)
        }

    except ClientError as e:
        # Authentication failed, handle the error
        return {
            'statusCode': 401,
            'headers': {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "*",  # Specify the allowed headers
                "Access-Control-Allow-Methods": "*",  # Specify the allowed HTTP methods
            },
            'body': json.dumps({'error': str(e)})
        }
